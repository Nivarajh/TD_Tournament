/**
 * Tous droits r�serv�s MIAGE Paris Ouest La D�fense
 */
package fr.miage.tournament.tests;

import fr.miage.tournament.Equipe;
import fr.miage.tournament.TournamentFactory;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Equipe</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class EquipeTest extends TestCase {

	/**
	 * The fixture for this Equipe test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Equipe fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(EquipeTest.class);
	}

	/**
	 * Constructs a new Equipe test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EquipeTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Equipe test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Equipe fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Equipe test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Equipe getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(TournamentFactory.eINSTANCE.createEquipe());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //EquipeTest
