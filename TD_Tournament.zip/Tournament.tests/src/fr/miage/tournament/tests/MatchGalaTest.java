/**
 * Tous droits r�serv�s MIAGE Paris Ouest La D�fense
 */
package fr.miage.tournament.tests;

import fr.miage.tournament.MatchGala;
import fr.miage.tournament.TournamentFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Match Gala</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class MatchGalaTest extends MatchTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(MatchGalaTest.class);
	}

	/**
	 * Constructs a new Match Gala test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MatchGalaTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Match Gala test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected MatchGala getFixture() {
		return (MatchGala)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(TournamentFactory.eINSTANCE.createMatchGala());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //MatchGalaTest
