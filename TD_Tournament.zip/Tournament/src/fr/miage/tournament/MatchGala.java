/**
 * Tous droits r�serv�s MIAGE Paris Ouest La D�fense
 */
package fr.miage.tournament;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Match Gala</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.miage.tournament.TournamentPackage#getMatchGala()
 * @model
 * @generated
 */
public interface MatchGala extends Match {
} // MatchGala
