/**
 * Tous droits r�serv�s MIAGE Paris Ouest La D�fense
 */
package fr.miage.tournament;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see fr.miage.tournament.TournamentFactory
 * @model kind="package"
 * @generated
 */
public interface TournamentPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "tournament";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://fr.miage.tournament";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "tournament";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	TournamentPackage eINSTANCE = fr.miage.tournament.impl.TournamentPackageImpl.init();

	/**
	 * The meta object id for the '{@link fr.miage.tournament.impl.JoueurImpl <em>Joueur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.miage.tournament.impl.JoueurImpl
	 * @see fr.miage.tournament.impl.TournamentPackageImpl#getJoueur()
	 * @generated
	 */
	int JOUEUR = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOUEUR__NOM = 0;

	/**
	 * The feature id for the '<em><b>Equipe</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOUEUR__EQUIPE = 1;

	/**
	 * The number of structural features of the '<em>Joueur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOUEUR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Joueur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JOUEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fr.miage.tournament.impl.EquipeImpl <em>Equipe</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.miage.tournament.impl.EquipeImpl
	 * @see fr.miage.tournament.impl.TournamentPackageImpl#getEquipe()
	 * @generated
	 */
	int EQUIPE = 1;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPE__NOM = 0;

	/**
	 * The feature id for the '<em><b>Joueurs</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPE__JOUEURS = 1;

	/**
	 * The number of structural features of the '<em>Equipe</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Equipe</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EQUIPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fr.miage.tournament.impl.MatchImpl <em>Match</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.miage.tournament.impl.MatchImpl
	 * @see fr.miage.tournament.impl.TournamentPackageImpl#getMatch()
	 * @generated
	 */
	int MATCH = 2;

	/**
	 * The feature id for the '<em><b>Equipe1</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH__EQUIPE1 = 0;

	/**
	 * The feature id for the '<em><b>Equipe2</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH__EQUIPE2 = 1;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH__NOM = 2;

	/**
	 * The feature id for the '<em><b>Equipes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH__EQUIPES = 3;

	/**
	 * The number of structural features of the '<em>Match</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Match</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link fr.miage.tournament.impl.MatchGalaImpl <em>Match Gala</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.miage.tournament.impl.MatchGalaImpl
	 * @see fr.miage.tournament.impl.TournamentPackageImpl#getMatchGala()
	 * @generated
	 */
	int MATCH_GALA = 3;

	/**
	 * The feature id for the '<em><b>Equipe1</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_GALA__EQUIPE1 = MATCH__EQUIPE1;

	/**
	 * The feature id for the '<em><b>Equipe2</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_GALA__EQUIPE2 = MATCH__EQUIPE2;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_GALA__NOM = MATCH__NOM;

	/**
	 * The feature id for the '<em><b>Equipes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_GALA__EQUIPES = MATCH__EQUIPES;

	/**
	 * The number of structural features of the '<em>Match Gala</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_GALA_FEATURE_COUNT = MATCH_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Match Gala</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MATCH_GALA_OPERATION_COUNT = MATCH_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.miage.tournament.impl.ScoreImpl <em>Score</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.miage.tournament.impl.ScoreImpl
	 * @see fr.miage.tournament.impl.TournamentPackageImpl#getScore()
	 * @generated
	 */
	int SCORE = 4;

	/**
	 * The feature id for the '<em><b>Score</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCORE__SCORE = 0;

	/**
	 * The feature id for the '<em><b>Matches</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCORE__MATCHES = 1;

	/**
	 * The number of structural features of the '<em>Score</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCORE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Score</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCORE_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link fr.miage.tournament.Joueur <em>Joueur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Joueur</em>'.
	 * @see fr.miage.tournament.Joueur
	 * @generated
	 */
	EClass getJoueur();

	/**
	 * Returns the meta object for the attribute '{@link fr.miage.tournament.Joueur#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see fr.miage.tournament.Joueur#getNom()
	 * @see #getJoueur()
	 * @generated
	 */
	EAttribute getJoueur_Nom();

	/**
	 * Returns the meta object for the reference '{@link fr.miage.tournament.Joueur#getEquipe <em>Equipe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Equipe</em>'.
	 * @see fr.miage.tournament.Joueur#getEquipe()
	 * @see #getJoueur()
	 * @generated
	 */
	EReference getJoueur_Equipe();

	/**
	 * Returns the meta object for class '{@link fr.miage.tournament.Equipe <em>Equipe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Equipe</em>'.
	 * @see fr.miage.tournament.Equipe
	 * @generated
	 */
	EClass getEquipe();

	/**
	 * Returns the meta object for the attribute '{@link fr.miage.tournament.Equipe#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see fr.miage.tournament.Equipe#getNom()
	 * @see #getEquipe()
	 * @generated
	 */
	EAttribute getEquipe_Nom();

	/**
	 * Returns the meta object for the reference list '{@link fr.miage.tournament.Equipe#getJoueurs <em>Joueurs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Joueurs</em>'.
	 * @see fr.miage.tournament.Equipe#getJoueurs()
	 * @see #getEquipe()
	 * @generated
	 */
	EReference getEquipe_Joueurs();

	/**
	 * Returns the meta object for class '{@link fr.miage.tournament.Match <em>Match</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Match</em>'.
	 * @see fr.miage.tournament.Match
	 * @generated
	 */
	EClass getMatch();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.miage.tournament.Match#getEquipe1 <em>Equipe1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Equipe1</em>'.
	 * @see fr.miage.tournament.Match#getEquipe1()
	 * @see #getMatch()
	 * @generated
	 */
	EReference getMatch_Equipe1();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.miage.tournament.Match#getEquipe2 <em>Equipe2</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Equipe2</em>'.
	 * @see fr.miage.tournament.Match#getEquipe2()
	 * @see #getMatch()
	 * @generated
	 */
	EReference getMatch_Equipe2();

	/**
	 * Returns the meta object for the attribute '{@link fr.miage.tournament.Match#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see fr.miage.tournament.Match#getNom()
	 * @see #getMatch()
	 * @generated
	 */
	EAttribute getMatch_Nom();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.miage.tournament.Match#getEquipes <em>Equipes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Equipes</em>'.
	 * @see fr.miage.tournament.Match#getEquipes()
	 * @see #getMatch()
	 * @generated
	 */
	EReference getMatch_Equipes();

	/**
	 * Returns the meta object for class '{@link fr.miage.tournament.MatchGala <em>Match Gala</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Match Gala</em>'.
	 * @see fr.miage.tournament.MatchGala
	 * @generated
	 */
	EClass getMatchGala();

	/**
	 * Returns the meta object for class '{@link fr.miage.tournament.Score <em>Score</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Score</em>'.
	 * @see fr.miage.tournament.Score
	 * @generated
	 */
	EClass getScore();

	/**
	 * Returns the meta object for the attribute '{@link fr.miage.tournament.Score#getScore <em>Score</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Score</em>'.
	 * @see fr.miage.tournament.Score#getScore()
	 * @see #getScore()
	 * @generated
	 */
	EAttribute getScore_Score();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.miage.tournament.Score#getMatches <em>Matches</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Matches</em>'.
	 * @see fr.miage.tournament.Score#getMatches()
	 * @see #getScore()
	 * @generated
	 */
	EReference getScore_Matches();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	TournamentFactory getTournamentFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link fr.miage.tournament.impl.JoueurImpl <em>Joueur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.miage.tournament.impl.JoueurImpl
		 * @see fr.miage.tournament.impl.TournamentPackageImpl#getJoueur()
		 * @generated
		 */
		EClass JOUEUR = eINSTANCE.getJoueur();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JOUEUR__NOM = eINSTANCE.getJoueur_Nom();

		/**
		 * The meta object literal for the '<em><b>Equipe</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JOUEUR__EQUIPE = eINSTANCE.getJoueur_Equipe();

		/**
		 * The meta object literal for the '{@link fr.miage.tournament.impl.EquipeImpl <em>Equipe</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.miage.tournament.impl.EquipeImpl
		 * @see fr.miage.tournament.impl.TournamentPackageImpl#getEquipe()
		 * @generated
		 */
		EClass EQUIPE = eINSTANCE.getEquipe();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EQUIPE__NOM = eINSTANCE.getEquipe_Nom();

		/**
		 * The meta object literal for the '<em><b>Joueurs</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EQUIPE__JOUEURS = eINSTANCE.getEquipe_Joueurs();

		/**
		 * The meta object literal for the '{@link fr.miage.tournament.impl.MatchImpl <em>Match</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.miage.tournament.impl.MatchImpl
		 * @see fr.miage.tournament.impl.TournamentPackageImpl#getMatch()
		 * @generated
		 */
		EClass MATCH = eINSTANCE.getMatch();

		/**
		 * The meta object literal for the '<em><b>Equipe1</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MATCH__EQUIPE1 = eINSTANCE.getMatch_Equipe1();

		/**
		 * The meta object literal for the '<em><b>Equipe2</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MATCH__EQUIPE2 = eINSTANCE.getMatch_Equipe2();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MATCH__NOM = eINSTANCE.getMatch_Nom();

		/**
		 * The meta object literal for the '<em><b>Equipes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MATCH__EQUIPES = eINSTANCE.getMatch_Equipes();

		/**
		 * The meta object literal for the '{@link fr.miage.tournament.impl.MatchGalaImpl <em>Match Gala</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.miage.tournament.impl.MatchGalaImpl
		 * @see fr.miage.tournament.impl.TournamentPackageImpl#getMatchGala()
		 * @generated
		 */
		EClass MATCH_GALA = eINSTANCE.getMatchGala();

		/**
		 * The meta object literal for the '{@link fr.miage.tournament.impl.ScoreImpl <em>Score</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.miage.tournament.impl.ScoreImpl
		 * @see fr.miage.tournament.impl.TournamentPackageImpl#getScore()
		 * @generated
		 */
		EClass SCORE = eINSTANCE.getScore();

		/**
		 * The meta object literal for the '<em><b>Score</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCORE__SCORE = eINSTANCE.getScore_Score();

		/**
		 * The meta object literal for the '<em><b>Matches</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCORE__MATCHES = eINSTANCE.getScore_Matches();

	}

} //TournamentPackage
