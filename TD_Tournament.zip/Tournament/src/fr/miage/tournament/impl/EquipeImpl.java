/**
 * Tous droits r�serv�s MIAGE Paris Ouest La D�fense
 */
package fr.miage.tournament.impl;

import fr.miage.tournament.Equipe;
import fr.miage.tournament.Joueur;
import fr.miage.tournament.TournamentPackage;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Equipe</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link fr.miage.tournament.impl.EquipeImpl#getNom <em>Nom</em>}</li>
 *   <li>{@link fr.miage.tournament.impl.EquipeImpl#getJoueurs <em>Joueurs</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EquipeImpl extends MinimalEObjectImpl.Container implements Equipe {
	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * The cached value of the '{@link #getJoueurs() <em>Joueurs</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJoueurs()
	 * @generated
	 * @ordered
	 */
	protected EList<Joueur> joueurs;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EquipeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TournamentPackage.Literals.EQUIPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TournamentPackage.EQUIPE__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Joueur> getJoueurs() {
		if (joueurs == null) {
			joueurs = new EObjectWithInverseResolvingEList<Joueur>(Joueur.class, this, TournamentPackage.EQUIPE__JOUEURS, TournamentPackage.JOUEUR__EQUIPE);
		}
		return joueurs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TournamentPackage.EQUIPE__JOUEURS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getJoueurs()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TournamentPackage.EQUIPE__JOUEURS:
				return ((InternalEList<?>)getJoueurs()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case TournamentPackage.EQUIPE__NOM:
				return getNom();
			case TournamentPackage.EQUIPE__JOUEURS:
				return getJoueurs();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case TournamentPackage.EQUIPE__NOM:
				setNom((String)newValue);
				return;
			case TournamentPackage.EQUIPE__JOUEURS:
				getJoueurs().clear();
				getJoueurs().addAll((Collection<? extends Joueur>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case TournamentPackage.EQUIPE__NOM:
				setNom(NOM_EDEFAULT);
				return;
			case TournamentPackage.EQUIPE__JOUEURS:
				getJoueurs().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case TournamentPackage.EQUIPE__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
			case TournamentPackage.EQUIPE__JOUEURS:
				return joueurs != null && !joueurs.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generatedNOT
	 */
	@Override
	public String toString() {
		//if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer();
		result.append(" (nom: ");
		result.append(nom);
		result.append(')');
		return result.toString();
	}

} //EquipeImpl
