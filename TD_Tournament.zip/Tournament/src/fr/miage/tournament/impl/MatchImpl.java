/**
 * Tous droits r�serv�s MIAGE Paris Ouest La D�fense
 */
package fr.miage.tournament.impl;

import fr.miage.tournament.Equipe;
import fr.miage.tournament.Joueur;
import fr.miage.tournament.Match;
import fr.miage.tournament.TournamentPackage;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Match</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link fr.miage.tournament.impl.MatchImpl#getEquipe1 <em>Equipe1</em>}</li>
 *   <li>{@link fr.miage.tournament.impl.MatchImpl#getEquipe2 <em>Equipe2</em>}</li>
 *   <li>{@link fr.miage.tournament.impl.MatchImpl#getNom <em>Nom</em>}</li>
 *   <li>{@link fr.miage.tournament.impl.MatchImpl#getEquipes <em>Equipes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MatchImpl extends MinimalEObjectImpl.Container implements Match {
	/**
	 * The cached value of the '{@link #getEquipe1() <em>Equipe1</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEquipe1()
	 * @generated
	 * @ordered
	 */
	protected EList<Joueur> equipe1;

	/**
	 * The cached value of the '{@link #getEquipe2() <em>Equipe2</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEquipe2()
	 * @generated
	 * @ordered
	 */
	protected EList<Joueur> equipe2;

	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * The cached value of the '{@link #getEquipes() <em>Equipes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEquipes()
	 * @generated
	 * @ordered
	 */
	protected EList<Equipe> equipes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MatchImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TournamentPackage.Literals.MATCH;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Joueur> getEquipe1() {
		if (equipe1 == null) {
			equipe1 = new EObjectContainmentEList<Joueur>(Joueur.class, this, TournamentPackage.MATCH__EQUIPE1);
		}
		return equipe1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Joueur> getEquipe2() {
		if (equipe2 == null) {
			equipe2 = new EObjectContainmentEList<Joueur>(Joueur.class, this, TournamentPackage.MATCH__EQUIPE2);
		}
		return equipe2;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TournamentPackage.MATCH__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Equipe> getEquipes() {
		if (equipes == null) {
			equipes = new EObjectContainmentEList<Equipe>(Equipe.class, this, TournamentPackage.MATCH__EQUIPES);
		}
		return equipes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TournamentPackage.MATCH__EQUIPE1:
				return ((InternalEList<?>)getEquipe1()).basicRemove(otherEnd, msgs);
			case TournamentPackage.MATCH__EQUIPE2:
				return ((InternalEList<?>)getEquipe2()).basicRemove(otherEnd, msgs);
			case TournamentPackage.MATCH__EQUIPES:
				return ((InternalEList<?>)getEquipes()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case TournamentPackage.MATCH__EQUIPE1:
				return getEquipe1();
			case TournamentPackage.MATCH__EQUIPE2:
				return getEquipe2();
			case TournamentPackage.MATCH__NOM:
				return getNom();
			case TournamentPackage.MATCH__EQUIPES:
				return getEquipes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case TournamentPackage.MATCH__EQUIPE1:
				getEquipe1().clear();
				getEquipe1().addAll((Collection<? extends Joueur>)newValue);
				return;
			case TournamentPackage.MATCH__EQUIPE2:
				getEquipe2().clear();
				getEquipe2().addAll((Collection<? extends Joueur>)newValue);
				return;
			case TournamentPackage.MATCH__NOM:
				setNom((String)newValue);
				return;
			case TournamentPackage.MATCH__EQUIPES:
				getEquipes().clear();
				getEquipes().addAll((Collection<? extends Equipe>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case TournamentPackage.MATCH__EQUIPE1:
				getEquipe1().clear();
				return;
			case TournamentPackage.MATCH__EQUIPE2:
				getEquipe2().clear();
				return;
			case TournamentPackage.MATCH__NOM:
				setNom(NOM_EDEFAULT);
				return;
			case TournamentPackage.MATCH__EQUIPES:
				getEquipes().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case TournamentPackage.MATCH__EQUIPE1:
				return equipe1 != null && !equipe1.isEmpty();
			case TournamentPackage.MATCH__EQUIPE2:
				return equipe2 != null && !equipe2.isEmpty();
			case TournamentPackage.MATCH__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
			case TournamentPackage.MATCH__EQUIPES:
				return equipes != null && !equipes.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generatedNOT
	 */
	@Override
	public String toString() {
		//if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer();
		result.append(" (nom: ");
		result.append(nom);
		
		result.append("\n\t").append("Equipe 1 :");
		for( Joueur j : getEquipe1()){
			result.append("\n\t\t").append(j.toString());
		}
		
		
		result.append("\n\t").append("Equipe 2 :");
		for( Joueur j : getEquipe2()){
			result.append("\n\t\t").append(j.toString());
		}
		
		result.append("\n");
		
		result.append(')');
		return result.toString();
	}

} //MatchImpl
