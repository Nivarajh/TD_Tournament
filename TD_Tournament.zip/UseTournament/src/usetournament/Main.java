package usetournament;


import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import fr.miage.tournament.Equipe;
import fr.miage.tournament.Joueur;
import fr.miage.tournament.Match;
import fr.miage.tournament.Score;
import fr.miage.tournament.TournamentFactory;

public final class Main {
	
	public static void main(String[] args)
	{
		
		Joueur j1 = TournamentFactory.eINSTANCE.createJoueur();
		j1.setNom("Joueur 1");
		Joueur j2 = TournamentFactory.eINSTANCE.createJoueur();
		j2.setNom("Joueur 2");
		
		Equipe e1 = TournamentFactory.eINSTANCE.createEquipe();
		e1.getJoueurs().add(j1);
		e1.setNom("Equipe 1");
		
		Equipe e2 = TournamentFactory.eINSTANCE.createEquipe();
		e2.getJoueurs().add(j2);
		e2.setNom("Equipe 2");
		
		Match m1 = TournamentFactory.eINSTANCE.createMatch();
		m1.setNom("Match 1");
		m1.getEquipe1().add(j1);
		m1.getEquipe2().add(j2);
		
		m1.getEquipes().add(e1);
		m1.getEquipes().add(e2);
		
		
		Score s1 = TournamentFactory.eINSTANCE.createScore();
		s1.getMatches().add(m1);
		
		s1.setScore("55-45");
		
		System.out.println(s1);
		
		
		
		 // Register the XMI resource factory for the .website extension
		
        Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
        Map<String, Object> m = reg.getExtensionToFactoryMap();
        m.put("tournament", new XMIResourceFactoryImpl());

        // Obtain a new resource set
        ResourceSet resSet = new ResourceSetImpl();

        // create a resource
        Resource resource = resSet.createResource(URI
                        .createURI("models/tournoi.tournament"));
        // Get the first model element and cast it to the right type, in my
        // example everything is hierarchical included in this first node
        resource.getContents().add(s1);

        // now save the content.
        try {
                resource.save(Collections.EMPTY_MAP);
        } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }
}
	
		
		
		
	}
	


